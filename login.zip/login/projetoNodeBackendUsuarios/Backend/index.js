require('dotenv').config()
const express = require('express')
const cors = require('cors')
const rotaUsuarios = require('./routes')

const app = express()
const PORT = process.env.PORT || 3000

app.use(cors())
app.use(express.json())

// Definindo o prefixo correto (removida a vírgula de dentro das aspas)
app.use('/api', rotaUsuarios)

app.listen(PORT, () => {
    console.log(`Servidor backend rodando na porta ${PORT}`)
})

-- drop database db_sistema_web;
create database db_sistema_web;
use db_sistema_web;
create table tbUsuarios(
id int not null auto_increment,
nome varchar(100) not null,
email varchar(100) not null unique,
primary key(id));

-- inserindo registros
insert into tbUsuarios(nome,email)
values('Maria Betania','maria.betania@hotmail.com');
insert into tbUsuarios(nome,email)
values('Juliana Alves','juliana.alves@gmail.com');